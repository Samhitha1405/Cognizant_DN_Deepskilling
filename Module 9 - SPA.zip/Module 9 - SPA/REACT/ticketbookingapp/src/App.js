import React, { useState } from 'react';
import GuestPage from './GuestPage';
import UserPage from './UserPage';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div style={{ fontFamily: 'Arial' }}>
      <div style={{ background: '#333', color: 'white', padding: '15px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ margin: 0 }}>✈ Flight Ticket Booking</h1>
        {isLoggedIn ? (
          <button onClick={() => setIsLoggedIn(false)} style={{ padding: '8px 16px', background: '#dc3545', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Logout
          </button>
        ) : (
          <button onClick={() => setIsLoggedIn(true)} style={{ padding: '8px 16px', background: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Login
          </button>
        )}
      </div>

      {/* Conditional Rendering */}
      {isLoggedIn
        ? <UserPage onLogout={() => setIsLoggedIn(false)} />
        : <GuestPage onLogin={() => setIsLoggedIn(true)} />
      }
    </div>
  );
}

export default App;
