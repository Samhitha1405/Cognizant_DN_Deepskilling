import React, { useState } from 'react';

function UserPage({ onLogout }) {
  const [booked, setBooked] = useState(null);
  const flights = [
    { id: 1, from: "Delhi", to: "Mumbai", date: "2024-03-15", price: "₹4,500" },
    { id: 2, from: "Bangalore", to: "Hyderabad", date: "2024-03-16", price: "₹3,200" },
    { id: 3, from: "Chennai", to: "Kolkata", date: "2024-03-17", price: "₹5,800" }
  ];

  return (
    <div style={{ padding: '20px' }}>
      <h2>Welcome! Book Your Flight</h2>
      {booked ? (
        <div style={{ background: '#d4edda', padding: '15px', borderRadius: '8px', color: '#155724' }}>
          <h3>✓ Booking Confirmed!</h3>
          <p>Flight: {booked.from} → {booked.to}</p>
          <p>Date: {booked.date} | Price: {booked.price}</p>
          <button onClick={() => setBooked(null)} style={{ padding: '5px 10px', cursor: 'pointer' }}>Book Another</button>
        </div>
      ) : (
        <table border="1" cellPadding="10" style={{ borderCollapse: 'collapse', width: '100%' }}>
          <thead style={{ background: '#28a745', color: 'white' }}>
            <tr><th>From</th><th>To</th><th>Date</th><th>Price</th><th>Action</th></tr>
          </thead>
          <tbody>
            {flights.map(f => (
              <tr key={f.id}>
                <td>{f.from}</td><td>{f.to}</td><td>{f.date}</td><td>{f.price}</td>
                <td><button onClick={() => setBooked(f)} style={{ padding: '5px 10px', background: '#28a745', color: 'white', border: 'none', cursor: 'pointer' }}>Book</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default UserPage;
