import React from 'react';

function GuestPage({ onLogin }) {
  const flights = [
    { id: 1, from: "Delhi", to: "Mumbai", date: "2024-03-15", price: "₹4,500" },
    { id: 2, from: "Bangalore", to: "Hyderabad", date: "2024-03-16", price: "₹3,200" },
    { id: 3, from: "Chennai", to: "Kolkata", date: "2024-03-17", price: "₹5,800" }
  ];

  return (
    <div style={{ padding: '20px' }}>
      <h2>Available Flights</h2>
      <p style={{ color: '#777' }}>Please login to book tickets</p>
      <table border="1" cellPadding="10" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead style={{ background: '#007bff', color: 'white' }}>
          <tr><th>From</th><th>To</th><th>Date</th><th>Price</th><th>Action</th></tr>
        </thead>
        <tbody>
          {flights.map(f => (
            <tr key={f.id}>
              <td>{f.from}</td><td>{f.to}</td><td>{f.date}</td><td>{f.price}</td>
              <td><button onClick={onLogin} style={{ padding: '5px 10px', cursor: 'pointer' }}>Login to Book</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default GuestPage;
