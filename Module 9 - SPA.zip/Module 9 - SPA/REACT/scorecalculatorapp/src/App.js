import React from 'react';
import CalculateScore from './Components/CalculateScore';

function App() {
  return (
    <div>
      <CalculateScore Name="John Doe" School="ABC School" Total={450} Goal={500} />
      <CalculateScore Name="Jane Smith" School="XYZ Academy" Total={380} Goal={500} />
    </div>
  );
}

export default App;
