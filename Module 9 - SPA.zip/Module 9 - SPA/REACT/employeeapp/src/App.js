import React, { Component } from 'react';
import ThemeContext from './ThemeContext';
import EmployeesList from './EmployeesList';

const employees = [
  { id: 1, name: "Amulya Singh", department: "Engineering", designation: "Senior Developer" },
  { id: 2, name: "Swetha Tiwari", department: "HR", designation: "HR Manager" },
  { id: 3, name: "Harsh Rathore", department: "Finance", designation: "Finance Analyst" }
];

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { theme: 'light' };
    this.toggleTheme = this.toggleTheme.bind(this);
  }

  toggleTheme() {
    this.setState(prev => ({ theme: prev.theme === 'light' ? 'dark' : 'light' }));
  }

  render() {
    const { theme } = this.state;
    const appStyle = {
      padding: '20px', minHeight: '100vh',
      background: theme === 'dark' ? '#222' : '#f5f5f5',
      color: theme === 'dark' ? 'white' : '#333',
      fontFamily: 'Arial'
    };

    return (
      <ThemeContext.Provider value={theme}>
        <div style={appStyle}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h1>Employee Management</h1>
            <button
              onClick={this.toggleTheme}
              style={{ padding: '8px 16px', cursor: 'pointer', borderRadius: '4px', border: 'none',
                background: theme === 'dark' ? '#ffc107' : '#333',
                color: theme === 'dark' ? '#333' : 'white' }}>
              Switch to {theme === 'dark' ? 'Light' : 'Dark'} Theme
            </button>
          </div>
          <p>Current Theme: <strong>{theme}</strong> (via Context API)</p>
          <EmployeesList employees={employees} />
        </div>
      </ThemeContext.Provider>
    );
  }
}

export default App;
