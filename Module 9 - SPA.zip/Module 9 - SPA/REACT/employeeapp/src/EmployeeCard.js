import React, { useContext } from 'react';
import ThemeContext from './ThemeContext';

function EmployeeCard({ employee }) {
  const theme = useContext(ThemeContext);

  const btnClass = theme === 'dark'
    ? { background: '#333', color: 'white', border: '1px solid #666' }
    : { background: '#007bff', color: 'white', border: 'none' };

  const cardStyle = {
    border: '1px solid #ccc',
    borderRadius: '8px',
    padding: '15px',
    marginBottom: '10px',
    background: theme === 'dark' ? '#444' : '#fff',
    color: theme === 'dark' ? 'white' : '#333'
  };

  return (
    <div style={cardStyle}>
      <h3>{employee.name}</h3>
      <p>Department: {employee.department}</p>
      <p>Designation: {employee.designation}</p>
      <button style={{ ...btnClass, padding: '5px 10px', borderRadius: '4px', cursor: 'pointer' }}>
        View Details
      </button>
    </div>
  );
}

export default EmployeeCard;
