import React, { Component } from 'react';
import GitClient from './GitClient';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: 'techiesyed',
      repos: [],
      loading: false,
      error: null
    };
    this.gitClient = new GitClient();
    this.handleFetch = this.handleFetch.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e) {
    this.setState({ username: e.target.value });
  }

  handleFetch() {
    this.setState({ loading: true, error: null, repos: [] });
    this.gitClient.getRepositories(this.state.username)
      .then(repos => this.setState({ repos, loading: false }))
      .catch(err => this.setState({ error: 'Failed to fetch repositories. Check the username.', loading: false }));
  }

  componentDidMount() {
    this.handleFetch();
  }

  render() {
    const { username, repos, loading, error } = this.state;
    return (
      <div style={{ padding: '20px', fontFamily: 'Arial' }}>
        <div style={{ background: '#24292e', color: 'white', padding: '15px', marginBottom: '20px', borderRadius: '8px' }}>
          <h1 style={{ margin: 0 }}>🐙 GitHub Repository Viewer</h1>
        </div>
        <div style={{ marginBottom: '20px' }}>
          <input
            type="text"
            value={username}
            onChange={this.handleChange}
            placeholder="GitHub username"
            style={{ padding: '10px', width: '250px', border: '1px solid #ccc', borderRadius: '4px', marginRight: '10px' }}
          />
          <button onClick={this.handleFetch} style={{ padding: '10px 20px', background: '#24292e', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Fetch Repos
          </button>
        </div>
        {loading && <p>Loading repositories...</p>}
        {error && <p style={{ color: 'red' }}>{error}</p>}
        {repos.length > 0 && (
          <div>
            <h3>Repositories for "{username}" ({repos.length} repos):</h3>
            <ul>
              {repos.map((repo, i) => (
                <li key={i} style={{ padding: '5px 0', borderBottom: '1px solid #eee' }}>
                  <a href={`https://github.com/${username}/${repo}`} target="_blank" rel="noreferrer">
                    {repo}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    );
  }
}

export default App;
