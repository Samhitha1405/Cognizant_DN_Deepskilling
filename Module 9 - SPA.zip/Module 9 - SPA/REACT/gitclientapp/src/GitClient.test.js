import axios from 'axios';
import GitClient from './GitClient';

jest.mock('axios');

describe('Git Client Tests', () => {
  test('should return repository names for techiesyed', () => {
    // Mock data
    const mockData = {
      data: [
        { name: 'repo-one' },
        { name: 'repo-two' },
        { name: 'repo-three' }
      ]
    };

    // Mock axios to return dummy data
    axios.get.mockResolvedValue(mockData);

    const client = new GitClient();
    return client.getRepositories('techiesyed').then(repos => {
      expect(repos).toEqual(['repo-one', 'repo-two', 'repo-three']);
      expect(axios.get).toHaveBeenCalledWith('https://api.github.com/users/techiesyed/repos');
    });
  });
});
