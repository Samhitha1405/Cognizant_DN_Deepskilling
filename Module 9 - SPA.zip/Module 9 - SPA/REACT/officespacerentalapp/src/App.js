import React from 'react';

function App() {
  // JSX object
  const office = {
    Name: "Prime Business Hub",
    Rent: 55000,
    Address: "MG Road, Bangalore - 560001"
  };

  // List of office objects
  const officeList = [
    { id: 1, Name: "TechPark Office", Rent: 45000, Address: "Whitefield, Bangalore" },
    { id: 2, Name: "Central Plaza", Rent: 75000, Address: "Connaught Place, Delhi" },
    { id: 3, Name: "Seashore Workspace", Rent: 38000, Address: "Bandra, Mumbai" },
    { id: 4, Name: "Silicon Valley Suite", Rent: 95000, Address: "Koramangala, Bangalore" },
    { id: 5, Name: "Heritage Office", Rent: 62000, Address: "Park Street, Kolkata" }
  ];

  // Inline CSS using JSX expression
  const getRentStyle = (rent) => ({
    color: rent < 60000 ? 'red' : 'green',
    fontWeight: 'bold'
  });

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      {/* Heading element */}
      <h1>Office Space Rental Portal</h1>

      {/* Image attribute */}
      <img
        src="https://via.placeholder.com/600x200?text=Office+Space"
        alt="Office Space"
        style={{ width: '100%', maxWidth: '600px', marginBottom: '20px' }}
      />

      {/* Single office details */}
      <h2>Featured Office</h2>
      <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '8px', maxWidth: '400px' }}>
        <p><strong>Name:</strong> {office.Name}</p>
        <p><strong>Rent:</strong> <span style={getRentStyle(office.Rent)}>₹{office.Rent.toLocaleString()}/month</span></p>
        <p><strong>Address:</strong> {office.Address}</p>
      </div>

      {/* List of offices */}
      <h2>All Available Offices</h2>
      <table border="1" cellPadding="10" style={{ borderCollapse: 'collapse', width: '100%', maxWidth: '700px' }}>
        <thead style={{ background: '#333', color: 'white' }}>
          <tr>
            <th>#</th>
            <th>Office Name</th>
            <th>Rent/Month</th>
            <th>Address</th>
          </tr>
        </thead>
        <tbody>
          {officeList.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.Name}</td>
              <td style={getRentStyle(item.Rent)}>₹{item.Rent.toLocaleString()}</td>
              <td>{item.Address}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p style={{ marginTop: '10px', fontSize: '14px' }}>
        <span style={{ color: 'red' }}>■</span> Red = Rent below ₹60,000 &nbsp;&nbsp;
        <span style={{ color: 'green' }}>■</span> Green = Rent above ₹60,000
      </p>
    </div>
  );
}

export default App;
