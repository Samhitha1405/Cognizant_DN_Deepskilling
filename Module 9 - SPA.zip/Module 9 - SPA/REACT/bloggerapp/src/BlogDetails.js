import React from 'react';

function BlogDetails() {
  const blogs = [
    { id: 1, title: "Getting Started with React Hooks", date: "2024-01-10", views: 1200 },
    { id: 2, title: "Understanding Context API", date: "2024-02-05", views: 850 },
    { id: 3, title: "React Router v6 Deep Dive", date: "2024-03-01", views: 2300 }
  ];

  return (
    <div>
      <h2>📝 Blog Details</h2>
      <ul>
        {blogs.map(blog => (
          <li key={blog.id} style={{ marginBottom: '8px' }}>
            <strong>{blog.title}</strong> — {blog.date} | 👁 {blog.views} views
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BlogDetails;
