import React from 'react';

function BookDetails() {
  const books = [
    { id: 1, title: "React: Up & Running", author: "Stoyan Stefanov", year: 2022 },
    { id: 2, title: "Learning JavaScript", author: "Ethan Brown", year: 2020 },
    { id: 3, title: "Clean Code", author: "Robert C. Martin", year: 2008 }
  ];

  return (
    <div>
      <h2>📚 Book Details</h2>
      {books.map(book => (
        <div key={book.id} style={{ border: '1px solid #ddd', padding: '10px', marginBottom: '10px', borderRadius: '5px' }}>
          <strong>{book.title}</strong> by {book.author} ({book.year})
        </div>
      ))}
    </div>
  );
}

export default BookDetails;
