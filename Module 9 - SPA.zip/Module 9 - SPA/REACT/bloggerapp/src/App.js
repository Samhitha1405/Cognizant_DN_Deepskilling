import React, { useState } from 'react';
import BookDetails from './BookDetails';
import BlogDetails from './BlogDetails';
import CourseDetails from './CourseDetails';

function App() {
  const [activeTab, setActiveTab] = useState('books');
  const [showAll, setShowAll] = useState(false);

  // Conditional rendering using multiple methods
  const renderContent = () => {
    // Method 1: if-else
    if (showAll) {
      return (
        <div>
          <BookDetails />
          <hr />
          <BlogDetails />
          <hr />
          <CourseDetails />
        </div>
      );
    }

    // Method 2: switch
    switch (activeTab) {
      case 'books': return <BookDetails />;
      case 'blogs': return <BlogDetails />;
      case 'courses': return <CourseDetails />;
      default: return null;
    }
  };

  const tabStyle = (tab) => ({
    padding: '10px 20px', cursor: 'pointer', marginRight: '5px',
    background: activeTab === tab ? '#007bff' : '#e9e9e9',
    color: activeTab === tab ? 'white' : '#333',
    border: 'none', borderRadius: '4px'
  });

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Blogger App</h1>
      <div style={{ marginBottom: '20px' }}>
        <button style={tabStyle('books')} onClick={() => { setActiveTab('books'); setShowAll(false); }}>Books</button>
        <button style={tabStyle('blogs')} onClick={() => { setActiveTab('blogs'); setShowAll(false); }}>Blogs</button>
        <button style={tabStyle('courses')} onClick={() => { setActiveTab('courses'); setShowAll(false); }}>Courses</button>
        {/* Method 3: ternary - Show All toggle */}
        <button
          style={{ padding: '10px 20px', marginLeft: '15px', cursor: 'pointer', background: showAll ? '#28a745' : '#6c757d', color: 'white', border: 'none', borderRadius: '4px' }}
          onClick={() => setShowAll(!showAll)}>
          {showAll ? 'Show Single' : 'Show All'}
        </button>
      </div>
      {renderContent()}
    </div>
  );
}

export default App;
