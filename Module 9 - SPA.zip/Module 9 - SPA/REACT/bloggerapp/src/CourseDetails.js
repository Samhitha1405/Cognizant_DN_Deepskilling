import React from 'react';

function CourseDetails() {
  const courses = [
    { id: 1, name: "React JS Fundamentals", duration: "40 hrs", level: "Beginner" },
    { id: 2, name: "Advanced React Patterns", duration: "30 hrs", level: "Advanced" },
    { id: 3, name: "Full Stack with MERN", duration: "80 hrs", level: "Intermediate" }
  ];

  return (
    <div>
      <h2>🎓 Course Details</h2>
      <table border="1" cellPadding="8" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead style={{ background: '#6c757d', color: 'white' }}>
          <tr><th>Course</th><th>Duration</th><th>Level</th></tr>
        </thead>
        <tbody>
          {courses.map(course => (
            <tr key={course.id}>
              <td>{course.name}</td>
              <td>{course.duration}</td>
              <td>{course.level}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CourseDetails;
