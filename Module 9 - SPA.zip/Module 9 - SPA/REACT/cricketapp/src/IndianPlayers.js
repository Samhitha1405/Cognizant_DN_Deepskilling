import React from 'react';

function IndianPlayers() {
  // Destructuring (ES6)
  const team = ["Player1", "Player2", "Player3", "Player4", "Player5",
                 "Player6", "Player7", "Player8", "Player9", "Player10", "Player11"];

  const [odd1, even1, odd2, even2, odd3, even3, odd4, even4, odd5, even5, odd6] = team;
  const oddPlayers = [odd1, odd2, odd3, odd4, odd5, odd6];
  const evenPlayers = [even1, even2, even3, even4, even5];

  // Spread/Merge feature of ES6
  const T20players = ["Rohit Sharma", "Virat Kohli", "Suryakumar Yadav", "Hardik Pandya", "Jasprit Bumrah"];
  const RanjiTrophyPlayers = ["Prithvi Shaw", "Sarfaraz Khan", "Musheer Khan", "Tanush Kotian", "Prasidh Krishna"];
  const mergedPlayers = [...T20players, ...RanjiTrophyPlayers];

  return (
    <div style={{ padding: '20px' }}>
      <h2>Team Destructuring (ES6)</h2>
      <h3>Odd Position Players</h3>
      <ul>{oddPlayers.map((p, i) => <li key={i}>{p}</li>)}</ul>
      <h3>Even Position Players</h3>
      <ul>{evenPlayers.map((p, i) => <li key={i}>{p}</li>)}</ul>

      <h2>Merged Team (T20 + Ranji Trophy) using Spread Operator</h2>
      <ul>{mergedPlayers.map((p, i) => <li key={i}>{p}</li>)}</ul>
    </div>
  );
}

export default IndianPlayers;
