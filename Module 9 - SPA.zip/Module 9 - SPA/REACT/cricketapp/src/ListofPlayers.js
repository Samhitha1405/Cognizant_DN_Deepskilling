import React from 'react';

function ListofPlayers() {
  const players = [
    { name: "Virat Kohli", score: 82 },
    { name: "Rohit Sharma", score: 65 },
    { name: "Shubman Gill", score: 91 },
    { name: "KL Rahul", score: 58 },
    { name: "Suryakumar Yadav", score: 74 },
    { name: "Hardik Pandya", score: 45 },
    { name: "Ravindra Jadeja", score: 33 },
    { name: "Axar Patel", score: 28 },
    { name: "Jasprit Bumrah", score: 12 },
    { name: "Mohammed Shami", score: 8 },
    { name: "Kuldeep Yadav", score: 15 }
  ];

  const lowScorers = players.filter(player => player.score < 70);

  return (
    <div style={{ padding: '20px' }}>
      <h2>All Players (using map)</h2>
      <ul>
        {players.map((player, index) => (
          <li key={index}>{player.name}: {player.score} runs</li>
        ))}
      </ul>
      <h2>Players with Score Below 70 (using filter + arrow function)</h2>
      <ul>
        {lowScorers.map((player, index) => (
          <li key={index} style={{ color: 'red' }}>{player.name}: {player.score} runs</li>
        ))}
      </ul>
    </div>
  );
}

export default ListofPlayers;
