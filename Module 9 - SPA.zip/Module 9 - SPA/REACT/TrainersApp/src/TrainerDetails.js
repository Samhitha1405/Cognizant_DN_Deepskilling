import React from 'react';
import { useParams, Link } from 'react-router-dom';
import TrainersMock from './TrainersMock';

function TrainerDetails() {
  const { id } = useParams();
  const trainer = TrainersMock.find(t => t.TrainerId === id);

  if (!trainer) {
    return <div style={{ padding: '20px' }}><h2>Trainer not found</h2><Link to="/trainers">Back to List</Link></div>;
  }

  return (
    <div style={{ padding: '20px' }}>
      <h2>Trainer Details</h2>
      <table border="1" cellPadding="10" style={{ borderCollapse: 'collapse' }}>
        <tbody>
          <tr><td><strong>T-ID</strong></td><td>{trainer.TrainerId}</td></tr>
          <tr><td><strong>Name</strong></td><td>{trainer.Name}</td></tr>
          <tr><td><strong>Email</strong></td><td>{trainer.Email}</td></tr>
          <tr><td><strong>Phone</strong></td><td>{trainer.Phone}</td></tr>
          <tr><td><strong>Technology</strong></td><td>{trainer.Technology}</td></tr>
          <tr><td><strong>Skills</strong></td><td>{trainer.Skills.join(', ')}</td></tr>
        </tbody>
      </table>
      <br />
      <Link to="/trainers">← Back to Trainers List</Link>
    </div>
  );
}

export default TrainerDetails;
