import Trainer from './trainer';

const TrainersMock = [
  new Trainer("T001", "Alice Johnson", "alice@gmail.com", "9876543210", "React", ["React", "Redux", "JavaScript"]),
  new Trainer("T002", "Sweta Tiwari", "tasweta@gmail.com", "9876543211", "Java", ["Java", "Spring Boot", "Hibernate"]),
  new Trainer("T003", "Harsh Mehra", "harsh@gmail.com", "9876543212", "Python", ["Python", "Django", "Flask"]),
  new Trainer("T004", "Dev Singh", "dev@gmail.com", "9876543213", "Angular", ["Angular", "TypeScript", "RxJS"]),
  new Trainer("T005", "Eve Davis", "eve@gmail.com", "9876543214", "Node.js", ["Node.js", "Express", "MongoDB"])
];

export default TrainersMock;
