import React from 'react';

function Home() {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Welcome to Trainers Portal</h2>
      <p>This application maintains a list of trainers along with their areas of expertise.</p>
      <p>Click on <strong>Trainers</strong> in the navigation to view the full list of trainers.</p>
    </div>
  );
}

export default Home;
