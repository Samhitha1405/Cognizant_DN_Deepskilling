import React from 'react';
import Register from './register';

function App() {
  return (
    <div>
      <div style={{ background: '#6f42c1', color: 'white', padding: '15px 30px' }}>
        <h1 style={{ margin: 0 }}>📧 Mail Register App</h1>
      </div>
      <Register />
    </div>
  );
}

export default App;
