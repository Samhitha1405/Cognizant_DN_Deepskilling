import React, { Component } from 'react';

class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      email: '',
      password: '',
      errors: {},
      submitted: false
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  validate() {
    const errors = {};
    const { name, email, password } = this.state;

    if (name.length < 5) {
      errors.name = 'Name should have at least 5 characters.';
    }
    if (!email.includes('@') || !email.includes('.')) {
      errors.email = 'Email should contain @ and . characters.';
    }
    if (password.length < 8) {
      errors.password = 'Password should have at least 8 characters.';
    }

    return errors;
  }

  handleChange(e) {
    this.setState({ [e.target.name]: e.target.value, errors: {}, submitted: false });
  }

  handleSubmit(e) {
    e.preventDefault();
    const errors = this.validate();
    if (Object.keys(errors).length > 0) {
      this.setState({ errors });
    } else {
      this.setState({ submitted: true, name: '', email: '', password: '', errors: {} });
    }
  }

  render() {
    const { name, email, password, errors, submitted } = this.state;
    const fieldStyle = { width: '100%', padding: '10px', marginTop: '5px', marginBottom: '5px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
    const errorStyle = { color: 'red', fontSize: '13px', marginBottom: '10px' };

    return (
      <div style={{ maxWidth: '450px', margin: '40px auto', padding: '30px', border: '1px solid #ddd', borderRadius: '10px', fontFamily: 'Arial' }}>
        <h2>User Registration</h2>
        {submitted && (
          <div style={{ background: '#d4edda', color: '#155724', padding: '10px', borderRadius: '4px', marginBottom: '15px' }}>
            ✓ Registration Successful!
          </div>
        )}
        <form onSubmit={this.handleSubmit}>
          <label><strong>Name:</strong></label>
          <input type="text" name="name" value={name} onChange={this.handleChange} placeholder="Enter your name (min 5 chars)" style={fieldStyle} />
          {errors.name && <p style={errorStyle}>{errors.name}</p>}

          <label><strong>Email:</strong></label>
          <input type="text" name="email" value={email} onChange={this.handleChange} placeholder="Enter your email" style={fieldStyle} />
          {errors.email && <p style={errorStyle}>{errors.email}</p>}

          <label><strong>Password:</strong></label>
          <input type="password" name="password" value={password} onChange={this.handleChange} placeholder="Enter password (min 8 chars)" style={fieldStyle} />
          {errors.password && <p style={errorStyle}>{errors.password}</p>}

          <button type="submit" style={{ width: '100%', padding: '12px', background: '#28a745', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '16px', marginTop: '10px' }}>
            Register
          </button>
        </form>
      </div>
    );
  }
}

export default Register;
