# Module 9 - SPA: React Hands-On Labs

This folder contains all 19 React Hands-On Labs. Each is a standalone React application.

## How to Run Any Lab

```bash
cd <app-folder>
npm install
npm start
```
Then open http://localhost:3000 in your browser.

---

## Lab Summary

| # | App Name | Topic | Key Concepts |
|---|----------|-------|-------------|
| 1 | myfirstreact | React Setup | create-react-app, JSX basics |
| 2 | StudentApp | Class Components | Multiple components, render() |
| 3 | scorecalculatorapp | Function Components | Props, CSS stylesheets |
| 4 | blogapp | Lifecycle Methods | componentDidMount, componentDidCatch, fetch API |
| 5 | cohortapp | CSS Modules | CSS Module, inline styles, className |
| 6 | TrainersApp | React Router | BrowserRouter, Routes, Route, Link, useParams |
| 7 | shoppingapp | Props | Class-to-class props, arrays |
| 8 | counterapp | State | setState, constructor, event binding |
| 9 | cricketapp | ES6 Features | map(), filter(), arrow functions, destructuring, spread |
| 10 | officespacerentalapp | JSX | createElement, expressions, inline CSS in JSX |
| 11 | eventexamplesapp | Events | onClick, synthetic events, multiple handlers, arguments |
| 12 | ticketbookingapp | Conditional Rendering | if-else, ternary, Login/Logout state |
| 13 | bloggerapp | Lists & Conditional | Keys, map(), if-else, switch, ternary |
| 14 | employeeapp | Context API | createContext, Provider, useContext, theme switching |
| 15 | ticketraisingapp | React Forms | Controlled components, handleSubmit, textarea |
| 16 | mailregisterapp | Form Validation | onChange, onSubmit, validation rules, error display |
| 17 | fetchuserapp | REST API | fetch(), componentDidMount, randomuser.me API |
| 18 | cohortapp-testing | Unit Testing | Jest, Enzyme, describe/test, shallow, mount, snapshot |
| 19 | gitclientapp | Mocking | axios, jest.mock(), getRepositories, GitHub API |

---

## Notes

- Labs 18 uses React 17 (required for Enzyme adapter compatibility)
- Lab 6 requires `react-router-dom` (already in package.json)
- Lab 19 requires `axios` (already in package.json)
- Labs 18 requires Enzyme: run `npm install enzyme @wojtekmaj/enzyme-adapter-react-17 --save-dev`
