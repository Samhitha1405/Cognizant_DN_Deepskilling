import React, { Component } from 'react';

class CountPeople extends Component {
  constructor(props) {
    super(props);
    this.state = {
      entrycount: 0,
      exitcount: 0
    };
  }

  UpdateEntry() {
    this.setState(prevState => ({ entrycount: prevState.entrycount + 1 }));
  }

  UpdateExit() {
    this.setState(prevState => ({ exitcount: prevState.exitcount + 1 }));
  }

  render() {
    return (
      <div style={{ padding: '30px', fontFamily: 'Arial' }}>
        <h1>Mall Visitor Counter</h1>
        <div style={{ marginBottom: '20px' }}>
          <p style={{ fontSize: '18px' }}>People Entered: <strong>{this.state.entrycount}</strong></p>
          <p style={{ fontSize: '18px' }}>People Exited: <strong>{this.state.exitcount}</strong></p>
          <p style={{ fontSize: '18px' }}>Currently Inside: <strong>{this.state.entrycount - this.state.exitcount}</strong></p>
        </div>
        <button
          onClick={() => this.UpdateEntry()}
          style={{ marginRight: '10px', padding: '10px 20px', background: '#28a745', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', fontSize: '16px' }}>
          Login (Entry)
        </button>
        <button
          onClick={() => this.UpdateExit()}
          style={{ padding: '10px 20px', background: '#dc3545', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', fontSize: '16px' }}>
          Exit
        </button>
      </div>
    );
  }
}

export default CountPeople;
