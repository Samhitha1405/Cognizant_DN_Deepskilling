import React, { Component } from 'react';

class CurrencyConvertor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      rupees: '',
      euros: null
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(e) {
    this.setState({ rupees: e.target.value });
  }

  handleSubmit(e) {
    e.preventDefault();
    const euroRate = 0.011; // 1 INR = 0.011 EUR (approx)
    const euros = (parseFloat(this.state.rupees) * euroRate).toFixed(2);
    this.setState({ euros });
  }

  render() {
    return (
      <div style={{ padding: '20px', borderTop: '2px solid #ccc', fontFamily: 'Arial' }}>
        <h2>Currency Convertor (INR → EUR)</h2>
        <form onSubmit={this.handleSubmit}>
          <label>Enter amount in Rupees (₹): </label>
          <input
            type="number"
            value={this.state.rupees}
            onChange={this.handleChange}
            style={{ marginLeft: '10px', padding: '5px', width: '150px' }}
            placeholder="Enter INR"
          />
          <br /><br />
          <button type="submit" style={{ padding: '8px 20px', background: '#ff8c00', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
            Convert
          </button>
        </form>
        {this.state.euros !== null && (
          <p style={{ marginTop: '15px', fontSize: '18px', color: '#28a745' }}>
            ₹{this.state.rupees} = <strong>€{this.state.euros}</strong>
          </p>
        )}
      </div>
    );
  }
}

export default CurrencyConvertor;
