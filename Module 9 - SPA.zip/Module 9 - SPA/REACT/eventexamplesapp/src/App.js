import React from 'react';
import EventDemo from './EventDemo';
import CurrencyConvertor from './CurrencyConvertor';

function App() {
  return (
    <div>
      <h1 style={{ padding: '20px', background: '#333', color: 'white', margin: 0 }}>Event Examples App</h1>
      <EventDemo />
      <CurrencyConvertor />
    </div>
  );
}

export default App;
