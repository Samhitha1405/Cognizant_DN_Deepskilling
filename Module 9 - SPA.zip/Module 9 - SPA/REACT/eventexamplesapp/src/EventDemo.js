import React, { Component } from 'react';

class EventDemo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
      message: ''
    };
    this.handleIncrement = this.handleIncrement.bind(this);
    this.handleDecrement = this.handleDecrement.bind(this);
    this.sayHello = this.sayHello.bind(this);
    this.sayWelcome = this.sayWelcome.bind(this);
    this.handleOnPress = this.handleOnPress.bind(this);
  }

  handleIncrement() {
    this.setState(prevState => ({ counter: prevState.counter + 1 }));
  }

  sayHello() {
    this.setState({ message: 'Hello! Welcome to Event Handling in React!' });
  }

  handleDecrement() {
    this.setState(prevState => ({ counter: prevState.counter - 1 }));
  }

  sayWelcome(msg) {
    this.setState({ message: `${msg} to React Event Handling!` });
  }

  handleOnPress(e) {
    // Synthetic event
    e.preventDefault();
    this.setState({ message: 'I was clicked (Synthetic Event)' });
  }

  render() {
    const btnStyle = { padding: '8px 16px', margin: '5px', cursor: 'pointer', borderRadius: '4px', border: 'none' };
    return (
      <div style={{ padding: '20px', fontFamily: 'Arial' }}>
        <h2>Event Demo</h2>
        <h3>Counter: {this.state.counter}</h3>

        {/* Increment button calls multiple methods */}
        <button style={{ ...btnStyle, background: '#28a745', color: 'white' }}
          onClick={() => { this.handleIncrement(); this.sayHello(); }}>
          Increment
        </button>

        <button style={{ ...btnStyle, background: '#dc3545', color: 'white' }}
          onClick={this.handleDecrement}>
          Decrement
        </button>

        <br /><br />

        {/* Button with argument */}
        <button style={{ ...btnStyle, background: '#007bff', color: 'white' }}
          onClick={() => this.sayWelcome('welcome')}>
          Say Welcome
        </button>

        {/* Synthetic event */}
        <button style={{ ...btnStyle, background: '#6f42c1', color: 'white' }}
          onClick={this.handleOnPress}>
          OnPress (Synthetic)
        </button>

        {this.state.message && (
          <p style={{ marginTop: '15px', padding: '10px', background: '#e9f5ff', borderRadius: '4px', color: '#007bff' }}>
            {this.state.message}
          </p>
        )}
      </div>
    );
  }
}

export default EventDemo;
