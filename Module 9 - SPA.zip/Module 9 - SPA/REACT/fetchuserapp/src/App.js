import React from 'react';
import Getuser from './Getuser';

function App() {
  return (
    <div>
      <div style={{ background: '#17a2b8', color: 'white', padding: '15px 30px' }}>
        <h1 style={{ margin: 0 }}>👤 Fetch User App</h1>
      </div>
      <Getuser />
    </div>
  );
}

export default App;
