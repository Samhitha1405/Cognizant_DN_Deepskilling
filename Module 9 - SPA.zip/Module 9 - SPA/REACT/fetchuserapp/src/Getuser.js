import React, { Component } from 'react';

class Getuser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: null,
      loading: true,
      error: null
    };
  }

  componentDidMount() {
    fetch('https://api.randomuser.me/')
      .then(response => response.json())
      .then(data => {
        const result = data.results[0];
        this.setState({
          user: {
            title: result.name.title,
            firstname: result.name.first,
            lastname: result.name.last,
            image: result.picture.large,
            email: result.email,
            phone: result.phone,
            location: `${result.location.city}, ${result.location.country}`
          },
          loading: false
        });
      })
      .catch(error => {
        this.setState({ error: error.message, loading: false });
      });
  }

  render() {
    const { user, loading, error } = this.state;

    if (loading) return <p style={{ padding: '20px' }}>Loading user data...</p>;
    if (error) return <p style={{ padding: '20px', color: 'red' }}>Error: {error}</p>;

    return (
      <div style={{ maxWidth: '400px', margin: '40px auto', padding: '30px', border: '1px solid #ddd', borderRadius: '10px', textAlign: 'center', fontFamily: 'Arial' }}>
        <img src={user.image} alt="User" style={{ borderRadius: '50%', width: '120px', height: '120px', border: '3px solid #007bff' }} />
        <h2>{user.title}. {user.firstname} {user.lastname}</h2>
        <p>📧 {user.email}</p>
        <p>📞 {user.phone}</p>
        <p>📍 {user.location}</p>
      </div>
    );
  }
}

export default Getuser;
