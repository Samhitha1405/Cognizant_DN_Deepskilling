import React, { Component } from 'react';

class ComplaintRegister extends Component {
  constructor(props) {
    super(props);
    this.state = {
      employeeName: '',
      complaint: ''
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  handleSubmit(e) {
    e.preventDefault();
    const refNumber = 'REF-' + Math.floor(100000 + Math.random() * 900000);
    alert(`Complaint Registered Successfully!\n\nEmployee: ${this.state.employeeName}\nComplaint: ${this.state.complaint}\n\nReference Number: ${refNumber}\n\nPlease use this reference number for further follow-ups.`);
    this.setState({ employeeName: '', complaint: '' });
  }

  render() {
    const inputStyle = { width: '100%', padding: '8px', marginTop: '5px', marginBottom: '15px', borderRadius: '4px', border: '1px solid #ccc', boxSizing: 'border-box' };
    return (
      <div style={{ maxWidth: '500px', margin: '40px auto', padding: '30px', border: '1px solid #ddd', borderRadius: '10px', fontFamily: 'Arial' }}>
        <h2>Complaint Registration</h2>
        <form onSubmit={this.handleSubmit}>
          <label><strong>Employee Name:</strong></label>
          <input
            type="text"
            name="employeeName"
            value={this.state.employeeName}
            onChange={this.handleChange}
            placeholder="Enter your name"
            required
            style={inputStyle}
          />
          <label><strong>Complaint:</strong></label>
          <textarea
            name="complaint"
            value={this.state.complaint}
            onChange={this.handleChange}
            placeholder="Describe your complaint in detail..."
            rows="5"
            required
            style={inputStyle}
          />
          <button type="submit" style={{ width: '100%', padding: '10px', background: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '16px' }}>
            Submit Complaint
          </button>
        </form>
      </div>
    );
  }
}

export default ComplaintRegister;
