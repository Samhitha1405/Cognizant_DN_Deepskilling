import React from 'react';
import ComplaintRegister from './ComplaintRegister';

function App() {
  return (
    <div>
      <div style={{ background: '#dc3545', color: 'white', padding: '15px 30px' }}>
        <h1 style={{ margin: 0 }}>🎫 Ticket Raising System</h1>
      </div>
      <ComplaintRegister />
    </div>
  );
}

export default App;
