import React, { Component } from 'react';

class Cart {
  constructor(Itemname, Price) {
    this.Itemname = Itemname;
    this.Price = Price;
  }
}

class OnlineShopping extends Component {
  constructor(props) {
    super(props);
    this.cartItems = [
      new Cart("Laptop", 75000),
      new Cart("Mobile Phone", 25000),
      new Cart("Headphones", 3500),
      new Cart("Keyboard", 2000),
      new Cart("Mouse", 1500)
    ];
  }

  render() {
    return (
      <div style={{ padding: '20px' }}>
        <h1>Online Shopping Cart</h1>
        <table border="1" cellPadding="10" style={{ borderCollapse: 'collapse', width: '400px' }}>
          <thead style={{ background: '#333', color: 'white' }}>
            <tr>
              <th>Item Name</th>
              <th>Price (₹)</th>
            </tr>
          </thead>
          <tbody>
            {this.cartItems.map((item, index) => (
              <tr key={index}>
                <td>{item.Itemname}</td>
                <td>₹{item.Price.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
          <tfoot style={{ background: '#f0f0f0' }}>
            <tr>
              <td><strong>Total</strong></td>
              <td><strong>₹{this.cartItems.reduce((sum, item) => sum + item.Price, 0).toLocaleString()}</strong></td>
            </tr>
          </tfoot>
        </table>
      </div>
    );
  }
}

export default OnlineShopping;
