export const CohortData = [
  { id: 1, code: "REACT-2024-01", name: "React Fundamentals", status: "ongoing", trainer: "Ava James", startDate: "2024-01-15", endDate: "2024-03-15" },
  { id: 2, code: "JAVA-2023-05", name: "Java Advanced", status: "completed", trainer: "Mairam Johnson", startDate: "2023-05-01", endDate: "2023-07-01" },
  { id: 3, code: "NODE-2024-02", name: "NodeJS Basics", status: "ongoing", trainer: "Sweta Tiwari", startDate: "2024-02-01", endDate: "2024-04-01" },
  { id: 4, code: "PYTHON-2023-09", name: "Python Essentials", status: "completed", trainer: "Prakash Sinha", startDate: "2023-09-01", endDate: "2023-11-01" }
];
