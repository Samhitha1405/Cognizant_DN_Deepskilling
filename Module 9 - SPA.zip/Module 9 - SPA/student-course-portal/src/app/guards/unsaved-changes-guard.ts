import { CanDeactivateFn } from '@angular/router';
import { FormGroup } from '@angular/forms';

export interface HasUnsavedChanges {
  enrollForm: FormGroup;
}

/**
 * HO7 Task2 – CanDeactivate functional guard
 * Warns the user before leaving a dirty reactive form.
 */
export const unsavedChangesGuard: CanDeactivateFn<HasUnsavedChanges> = (component) => {
  if (component.enrollForm && component.enrollForm.dirty) {
    return window.confirm('You have unsaved changes. Leave anyway?');
  }
  return true;
};
