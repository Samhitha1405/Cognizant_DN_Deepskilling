import { Injectable } from '@angular/core';
import { Course } from '../models/course.model';
import { CourseService } from './course';

@Injectable({ providedIn: 'root' })
export class EnrollmentService {
  private enrolledCourseIds: number[] = [1, 3]; // pre-enrolled for demo

  // Service-to-service injection (HO6 Task2)
  constructor(private courseService: CourseService) {}

  enroll(courseId: number): void {
    if (!this.isEnrolled(courseId)) {
      this.enrolledCourseIds = [...this.enrolledCourseIds, courseId];
    }
  }

  unenroll(courseId: number): void {
    this.enrolledCourseIds = this.enrolledCourseIds.filter(id => id !== courseId);
  }

  isEnrolled(courseId: number): boolean {
    return this.enrolledCourseIds.includes(courseId);
  }

  /** Resolves IDs to full Course objects using CourseService */
  getEnrolledCourses(): Course[] {
    return this.enrolledCourseIds
      .map(id => this.courseService.getCourseByIdSync(id))
      .filter((c): c is Course => c !== undefined);
  }

  getEnrolledIds(): number[] {
    return [...this.enrolledCourseIds];
  }
}
