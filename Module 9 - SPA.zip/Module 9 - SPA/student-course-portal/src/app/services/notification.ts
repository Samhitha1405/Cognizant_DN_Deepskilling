import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

// This service is intentionally provided at COMPONENT level in NotificationComponent
// to demonstrate scoped (non-singleton) DI — each component gets its own instance
@Injectable()
export class NotificationService {
  private messages$ = new BehaviorSubject<string[]>([]);
  messages = this.messages$.asObservable();

  push(msg: string): void {
    this.messages$.next([...this.messages$.value, msg]);
  }

  clear(): void { this.messages$.next([]); }
}
