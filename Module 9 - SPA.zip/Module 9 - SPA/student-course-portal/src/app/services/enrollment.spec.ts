import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EnrollmentService } from './enrollment';
import { CourseService } from './course';

describe('EnrollmentService', () => {
  let service: EnrollmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [HttpClientTestingModule], providers: [EnrollmentService, CourseService] });
    service = TestBed.inject(EnrollmentService);
  });

  it('should be created',          () => expect(service).toBeTruthy());
  it('should enroll in a course',  () => { service.enroll(5); expect(service.isEnrolled(5)).toBeTrue(); });
  it('should unenroll',            () => { service.enroll(5); service.unenroll(5); expect(service.isEnrolled(5)).toBeFalse(); });
  it('should not duplicate enroll',() => { service.enroll(1); service.enroll(1); expect(service.getEnrolledIds().filter(id => id===1).length).toBe(1); });
});
