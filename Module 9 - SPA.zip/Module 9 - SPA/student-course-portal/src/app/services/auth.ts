import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // Hardcoded for HO7 guard demo — in production this would check a JWT
  isLoggedIn = true;

  login(): void { this.isLoggedIn = true; }
  logout(): void { this.isLoggedIn = false; }
}
