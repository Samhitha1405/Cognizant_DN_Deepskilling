import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError, tap, retry } from 'rxjs/operators';
import { Course } from '../models/course.model';

@Injectable({ providedIn: 'root' })
export class CourseService {
  private apiUrl = 'http://localhost:3000/courses';

  // Fallback in-memory data used when JSON Server is not running
  private courses: Course[] = [
    { id: 1, name: 'Data Structures', code: 'CS101', credits: 4, gradeStatus: 'passed', description: 'Arrays, linked lists, trees, graphs.', instructor: 'Dr. Smith' },
    { id: 2, name: 'Operating Systems', code: 'CS202', credits: 3, gradeStatus: 'pending', description: 'Processes, memory management, I/O.', instructor: 'Prof. Jones' },
    { id: 3, name: 'Web Development', code: 'CS303', credits: 4, gradeStatus: 'passed', description: 'HTML, CSS, JavaScript, Angular.', instructor: 'Dr. Lee' },
    { id: 4, name: 'Database Systems', code: 'CS404', credits: 3, gradeStatus: 'failed', description: 'SQL, normalization, transactions.', instructor: 'Prof. Kumar' },
    { id: 5, name: 'Machine Learning', code: 'CS505', credits: 4, gradeStatus: 'pending', description: 'Supervised & unsupervised learning.', instructor: 'Dr. Patel' },
    { id: 6, name: 'Computer Networks', code: 'CS606', credits: 3, gradeStatus: 'passed', description: 'TCP/IP, HTTP, sockets, DNS.', instructor: 'Prof. Ali' },
    { id: 7, name: 'Software Engineering', code: 'CS707', credits: 4, gradeStatus: 'pending', description: 'SDLC, Agile, design patterns.', instructor: 'Dr. Brown' },
  ];

  constructor(private http: HttpClient) {}

  /** GET all courses from API; falls back gracefully via catchError */
  getCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(this.apiUrl).pipe(
      tap(courses => console.log('Courses loaded from API:', courses.length)),
      map(courses => courses.filter(c => c.credits > 0)),   // HO8 Task2 – map operator
      retry(2),                                              // HO8 Task2 – retry strategy
      catchError(err => {
        console.error('API error, using in-memory data:', err.message);
        // Graceful fallback to local data when JSON Server is offline
        return new Observable<Course[]>(observer => {
          observer.next(this.courses);
          observer.complete();
        });
      })
    );
  }

  /** GET single course by id */
  getCourseById(id: number): Observable<Course | undefined> {
    return this.http.get<Course>(`${this.apiUrl}/${id}`).pipe(
      catchError(() => {
        const found = this.courses.find(c => c.id === id);
        return new Observable<Course | undefined>(o => { o.next(found); o.complete(); });
      })
    );
  }

  /** Synchronous helper used by EnrollmentService internally */
  getCourseByIdSync(id: number): Course | undefined {
    return this.courses.find(c => c.id === id);
  }

  /** POST – create a new course */
  createCourse(course: Omit<Course, 'id'>): Observable<Course> {
    return this.http.post<Course>(this.apiUrl, course);
  }

  /** PUT – update an existing course */
  updateCourse(id: number, course: Course): Observable<Course> {
    return this.http.put<Course>(`${this.apiUrl}/${id}`, course);
  }

  /** DELETE – remove a course */
  deleteCourse(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  /** Synchronous add for in-memory demo (HO6 Task1 singleton test) */
  addCourse(course: Course): void {
    this.courses = [...this.courses, course];
  }

  getCoursesSync(): Course[] {
    return this.courses;
  }
}
