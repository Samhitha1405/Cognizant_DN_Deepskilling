import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class LoadingService {
  // BehaviorSubject emits the current value to any new subscriber immediately
  isLoading$ = new BehaviorSubject<boolean>(false);

  show(): void { this.isLoading$.next(true); }
  hide(): void { this.isLoading$.next(false); }
}
