import { TestBed } from '@angular/core/testing';
import { AuthService } from './auth';

describe('AuthService', () => {
  let service: AuthService;
  beforeEach(() => { TestBed.configureTestingModule({}); service = TestBed.inject(AuthService); });

  it('should be created',           () => expect(service).toBeTruthy());
  it('should be logged in by default', () => expect(service.isLoggedIn).toBeTrue());
  it('should logout',               () => { service.logout(); expect(service.isLoggedIn).toBeFalse(); });
  it('should login',                () => { service.logout(); service.login(); expect(service.isLoggedIn).toBeTrue(); });
});
