import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CourseService } from './course';
import { Course } from '../models/course.model';

/**
 * HO10 Task2 – Service tests using HttpClientTestingModule
 * Tests: getCourses(), error handling, correct URL called
 */
describe('CourseService', () => {
  let service: CourseService;
  let httpMock: HttpTestingController;

  const mockCourses: Course[] = [
    { id: 1, name: 'Data Structures', code: 'CS101', credits: 4, gradeStatus: 'passed' },
    { id: 2, name: 'Operating Systems', code: 'CS202', credits: 3, gradeStatus: 'pending' }
  ];

  // HO10 Task2 Step 106 – Configure TestBed with HttpClientTestingModule
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CourseService]
    });
    service  = TestBed.inject(CourseService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  // HO10 Task2 Step 107 – Verify no outstanding requests after each test
  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // HO10 Task2 Step 107 – getCourses() test
  it('should fetch courses from the correct URL', () => {
    service.getCourses().subscribe(courses => {
      expect(courses.length).toBe(2);
      expect(courses[0].name).toBe('Data Structures');
    });

    // Intercept the HTTP request and flush mock data
    const req = httpMock.expectOne('http://localhost:3000/courses');
    expect(req.request.method).toBe('GET');
    req.flush(mockCourses);
  });

  // HO10 Task2 Step 107 – Verify correct URL called
  it('should call GET http://localhost:3000/courses', () => {
    service.getCourses().subscribe();
    const req = httpMock.expectOne('http://localhost:3000/courses');
    expect(req.request.method).toEqual('GET');
    req.flush([]);
  });

  // HO10 Task2 Step 108 – Error handling test
  it('should handle HTTP errors gracefully by returning fallback data', () => {
    service.getCourses().subscribe({
      next: courses => {
        // When API fails, getCourses() returns local fallback data (not an error)
        expect(courses.length).toBeGreaterThan(0);
      }
    });

    const req = httpMock.expectOne('http://localhost:3000/courses');
    // First retry — flush error
    req.flush('Server Error', { status: 500, statusText: 'Internal Server Error' });
  });

  it('should return a course synchronously by id', () => {
    const course = service.getCourseByIdSync(1);
    expect(course).toBeDefined();
    expect(course?.id).toBe(1);
  });

  it('should return undefined for a non-existent id', () => {
    const course = service.getCourseByIdSync(999);
    expect(course).toBeUndefined();
  });
});
