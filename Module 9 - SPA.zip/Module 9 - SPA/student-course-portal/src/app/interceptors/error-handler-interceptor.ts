import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

/**
 * HO8 Task3 – Global Error Interceptor
 * Handles 401 (redirect to home) and 500 (log global error) centrally.
 */
export const errorHandlerInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401) {
        console.warn('Unauthorised — redirecting to home');
        router.navigate(['/']);
      } else if (error.status === 500) {
        console.error('Server error — show global notification');
      }
      // Re-throw so individual subscribers can also handle the error
      return throwError(() => error);
    })
  );
};
