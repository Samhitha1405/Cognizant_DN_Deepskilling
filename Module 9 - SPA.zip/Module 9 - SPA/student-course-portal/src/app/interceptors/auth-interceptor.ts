import { HttpInterceptorFn } from '@angular/common/http';

/**
 * HO8 Task3 – Auth Interceptor
 * Clones every outgoing request and attaches a Bearer token header.
 * Interceptors run in registration order; responses arrive in reverse order.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authReq = req.clone({
    setHeaders: {
      Authorization: 'Bearer mock-token-12345'
    }
  });
  return next(authReq);
};
