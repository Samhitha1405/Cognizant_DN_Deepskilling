import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { LoadingService } from '../services/loading';

/**
 * HO8 Task3 – Loading Interceptor
 * Shows a global spinner before each HTTP request and hides it when done.
 * finalize() runs whether the Observable completes OR errors — equivalent to try/finally.
 */
export const loadingInterceptor: HttpInterceptorFn = (req, next) => {
  const loadingService = inject(LoadingService);
  loadingService.show();

  return next(req).pipe(
    finalize(() => loadingService.hide())
  );
};
