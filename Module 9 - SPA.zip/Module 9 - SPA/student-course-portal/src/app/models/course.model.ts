// Course model — shared data structure across the entire portal
export interface Course {
  id: number;
  name: string;
  code: string;
  credits: number;
  gradeStatus: 'passed' | 'failed' | 'pending';
  description?: string;
  instructor?: string;
  enrolled?: boolean;
}

export interface Student {
  id: number;
  name: string;
  email: string;
  gpa: number;
  enrolledCourseIds: number[];
}
