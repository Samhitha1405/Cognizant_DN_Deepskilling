import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AsyncPipe } from '@angular/common';
import { HeaderComponent }  from './components/header/header';
import { LoadingService }   from './services/loading';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, AsyncPipe],
  template: `
    <!-- HO8 Task3 – global loading spinner bound to loadingService.isLoading$ via async pipe -->
    @if (loadingService.isLoading$ | async) {
      <div class="global-spinner">
        <div class="spinner"></div>
        <span>Loading...</span>
      </div>
    }
    <app-header />
    <main class="portal-main">
      <router-outlet />
    </main>
  `,
  styles: [`
    .global-spinner {
      position: fixed; top: 0; left: 0; right: 0; z-index: 9999;
      background: rgba(0,0,0,0.4); height: 4px;
      display: flex; align-items: center; justify-content: center;
    }
    .spinner {
      width: 24px; height: 24px; border: 3px solid #fff;
      border-top-color: #4f46e5; border-radius: 50%;
      animation: spin 0.7s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    .portal-main { max-width: 1200px; margin: 0 auto; padding: 24px 16px; }
  `]
})
export class AppComponent {
  constructor(public loadingService: LoadingService) {}
}
