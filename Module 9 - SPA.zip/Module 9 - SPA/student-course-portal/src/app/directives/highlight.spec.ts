import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { HighlightDirective } from './highlight';

@Component({ standalone: true, imports: [HighlightDirective], template: `<p appHighlight="lightblue">Hover me</p>` })
class TestHostComponent {}

describe('HighlightDirective', () => {
  let fixture: ComponentFixture<TestHostComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({ imports: [TestHostComponent] });
    fixture = TestBed.createComponent(TestHostComponent);
    fixture.detectChanges();
  });

  it('should create', () => expect(fixture.componentInstance).toBeTruthy());

  it('should apply background colour on mouseenter', () => {
    const el = fixture.debugElement.query(By.directive(HighlightDirective));
    el.triggerEventHandler('mouseenter', {});
    fixture.detectChanges();
    expect(el.nativeElement.style.backgroundColor).toBe('lightblue');
  });

  it('should remove background colour on mouseleave', () => {
    const el = fixture.debugElement.query(By.directive(HighlightDirective));
    el.triggerEventHandler('mouseenter', {});
    el.triggerEventHandler('mouseleave', {});
    fixture.detectChanges();
    expect(el.nativeElement.style.backgroundColor).toBe('');
  });
});
