import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

/**
 * HO3 Task3 – Custom Attribute Directive
 * Usage: <element appHighlight> or <element appHighlight="lightblue">
 * Adds a coloured background on mouseenter, removes it on mouseleave.
 */
@Directive({
  selector: '[appHighlight]',
  standalone: true
})
export class HighlightDirective {
  // Configurable colour — defaults to yellow (HO3 Step 37)
  @Input() appHighlight: string = 'yellow';

  constructor(private el: ElementRef, private renderer: Renderer2) {}

  @HostListener('mouseenter')
  onMouseEnter(): void {
    this.renderer.setStyle(this.el.nativeElement, 'background-color', this.appHighlight);
    this.renderer.setStyle(this.el.nativeElement, 'transition', 'background-color 0.2s ease');
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
    this.renderer.removeStyle(this.el.nativeElement, 'background-color');
  }
}
