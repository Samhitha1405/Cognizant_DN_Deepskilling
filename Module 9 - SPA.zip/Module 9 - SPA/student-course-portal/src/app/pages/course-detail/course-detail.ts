import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CourseService } from '../../services/course';
import { Course } from '../../models/course.model';

/**
 * HO7 Task1 – Reads :id route parameter via ActivatedRoute.
 * Uses CourseService.getCourseByIdSync() to load and display the matching course.
 */
@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [RouterLink, TitleCasePipe],
  templateUrl: './course-detail.html',
  styleUrl: './course-detail.css'
})
export class CourseDetailComponent implements OnInit {
  course: Course | undefined;

  constructor(private route: ActivatedRoute, private courseService: CourseService) {}

  ngOnInit(): void {
    // HO7 Task1 – snapshot.paramMap is fine here; the id does not change while this component is active
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.course = this.courseService.getCourseByIdSync(id);
  }
}
