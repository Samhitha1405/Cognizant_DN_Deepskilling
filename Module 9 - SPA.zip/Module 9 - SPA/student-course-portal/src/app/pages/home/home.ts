import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CourseService } from '../../services/course';
import { CourseSummaryWidgetComponent } from '../../components/course-summary-widget/course-summary-widget';

/**
 * HO2 Task1 – All four binding types demonstrated
 * HO2 Task2 – ngOnInit and ngOnDestroy lifecycle hooks
 */
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [FormsModule, RouterLink, CourseSummaryWidgetComponent],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class HomeComponent implements OnInit, OnDestroy {
  // HO2 Task1 – Interpolation
  portalName = 'Student Course Portal';

  // HO2 Task1 – Property binding
  isPortalActive = true;

  // HO2 Task1 – Event binding result
  message = '';

  // HO2 Task1 – Two-way binding with ngModel
  // [(ngModel)] is shorthand for [ngModel]="searchTerm" (ngModelChange)="searchTerm=$event"
  // [property] is ONE-WAY (component → DOM); [(ngModel)] is TWO-WAY (DOM ↔ component)
  searchTerm = '';

  // Stats — populated in ngOnInit
  coursesAvailable = 0;
  enrolled = 3;
  gpa = 3.8;

  constructor(private courseService: CourseService) {}

  /** HO2 Task2 – ngOnInit: best place for data fetching (inputs are set, unlike constructor) */
  ngOnInit(): void {
    this.coursesAvailable = this.courseService.getCoursesSync().length;
    console.log('HomeComponent initialised — courses loaded:', this.coursesAvailable);
  }

  /** HO2 Task2 – ngOnDestroy: cleanup subscriptions/timers to prevent memory leaks */
  ngOnDestroy(): void {
    console.log('HomeComponent destroyed');
  }

  /** HO2 Task1 – Event binding handler */
  onEnrollClick(): void {
    this.message = 'Enrollment opened! Head to the Enroll page.';
  }
}
