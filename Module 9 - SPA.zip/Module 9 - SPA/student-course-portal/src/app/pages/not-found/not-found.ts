import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div style="text-align:center;padding:80px 20px">
      <div style="font-size:5rem">🔍</div>
      <h2 style="color:#1e1b4b;font-size:2rem">404 — Page Not Found</h2>
      <p style="color:#6b7280">The page you are looking for doesn't exist or has been moved.</p>
      <a routerLink="/" style="color:#4f46e5;font-weight:600;text-decoration:none">← Back to Home</a>
    </div>
  `
})
export class NotFoundComponent {}
