import { Component, OnInit } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Course } from '../../models/course.model';
import { CourseCardComponent } from '../../components/course-card/course-card';
import { loadCourses } from '../../store/course/course.actions';
import { selectAllCourses, selectCoursesLoading, selectCoursesError } from '../../store/course/course.selectors';

/**
 * HO3 Task1 – Structural directives: *ngFor with trackBy, *ngIf with else, *ngSwitch
 * HO6 Task1 – CourseService injected (now via NgRx store)
 * HO9 Task1 – Dispatches loadCourses(), binds to store selectors via async pipe
 */
@Component({
  selector: 'app-course-list',
  standalone: true,
  imports: [AsyncPipe, CourseCardComponent],
  templateUrl: './course-list.html',
  styleUrl: './course-list.css'
})
export class CourseListComponent implements OnInit {
  // HO9 Task1 – Observable streams from NgRx store selectors
  courses$: Observable<Course[]>;
  isLoading$: Observable<boolean>;
  errorMessage$: Observable<string | null>;

  // For local selected-course display (HO2 Task3)
  selectedCourseId: number | null = null;

  constructor(private store: Store, private router: Router) {
    this.courses$     = this.store.select(selectAllCourses);
    this.isLoading$   = this.store.select(selectCoursesLoading);
    this.errorMessage$ = this.store.select(selectCoursesError);
  }

  ngOnInit(): void {
    // HO9 Task1 – Dispatch triggers the Effect → HTTP → loadCoursesSuccess → reducer
    this.store.dispatch(loadCourses());
  }

  /**
   * HO3 Task1 – trackBy function.
   * Without trackBy, Angular destroys and recreates every list item on any array change.
   * With trackBy, only items whose identity (course.id) changed are re-rendered.
   * This dramatically improves performance for large lists.
   */
  trackByCourseId(_index: number, course: Course): number {
    return course.id;
  }

  /** HO2 Task3 – receives the enrollRequested output from CourseCardComponent */
  onEnroll(courseId: number): void {
    console.log('Enrolling in course:', courseId);
    this.selectedCourseId = courseId;
  }

  /** HO7 Task1 – programmatic navigation to course detail */
  onCardClick(courseId: number): void {
    this.router.navigate(['courses', courseId]);
  }
}
