import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { CourseListComponent } from './course-list';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Course } from '../../models/course.model';

/**
 * HO10 Task2 Steps 109-110 – NgRx MockStore component tests
 */
describe('CourseListComponent', () => {
  let component: CourseListComponent;
  let fixture: ComponentFixture<CourseListComponent>;
  let store: MockStore;

  const mockCourses: Course[] = [
    { id: 1, name: 'Data Structures', code: 'CS101', credits: 4, gradeStatus: 'passed' },
    { id: 2, name: 'Web Dev', code: 'CS303', credits: 3, gradeStatus: 'pending' }
  ];

  const initialState = {
    course: { courses: mockCourses, loading: false, error: null },
    enrollment: { enrolledCourseIds: [] }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CourseListComponent, HttpClientTestingModule, RouterTestingModule],
      providers: [provideMockStore({ initialState })]
    }).compileComponents();

    store     = TestBed.inject(MockStore);
    fixture   = TestBed.createComponent(CourseListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // HO10 Task2 Step 109 – Initial state renders course cards
  it('should render course cards matching initial store state', () => {
    const cards = fixture.debugElement.queryAll(By.css('app-course-card'));
    expect(cards.length).toBe(mockCourses.length);
  });

  // HO10 Task2 Step 110 – Loading state
  it('should show loading indicator when store loading is true', () => {
    store.setState({ course: { courses: [], loading: true, error: null }, enrollment: { enrolledCourseIds: [] } });
    fixture.detectChanges();
    const loadingEl = fixture.debugElement.query(By.css('.loading-text'));
    expect(loadingEl).toBeTruthy();
    expect(loadingEl.nativeElement.textContent).toContain('Loading');
  });

  it('should show no-courses message when courses array is empty', () => {
    store.setState({ course: { courses: [], loading: false, error: null }, enrollment: { enrolledCourseIds: [] } });
    fixture.detectChanges();
    const noCoursesEl = fixture.debugElement.query(By.css('.no-courses'));
    expect(noCoursesEl).toBeTruthy();
  });
});
