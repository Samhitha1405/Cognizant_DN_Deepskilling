import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AsyncPipe } from '@angular/common';
import { Course } from '../../models/course.model';
import { selectEnrolledCourses } from '../../store/enrollment/enrollment.selectors';

/**
 * HO6 Task2 – Displays enrolled courses using EnrollmentService.
 * HO9     – Now uses the cross-slice NgRx selector (selectEnrolledCourses).
 */
@Component({
  selector: 'app-student-profile',
  standalone: true,
  imports: [AsyncPipe],
  templateUrl: './student-profile.html',
  styleUrl: './student-profile.css'
})
export class StudentProfileComponent implements OnInit {
  enrolledCourses$: Observable<Course[]>;

  student = { name: 'Alex Johnson', email: 'alex.johnson@university.edu', gpa: 3.8, year: 'Junior' };

  constructor(private store: Store) {
    // Cross-slice selector: joins course + enrollment state slices (HO9 Task2)
    this.enrolledCourses$ = this.store.select(selectEnrolledCourses);
  }

  ngOnInit(): void {}
}
