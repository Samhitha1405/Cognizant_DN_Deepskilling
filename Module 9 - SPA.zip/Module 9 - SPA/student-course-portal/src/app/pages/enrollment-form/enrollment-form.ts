import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';


/**
 * HO4 – Template-Driven Form
 * Demonstrates: ngModel two-way binding, ngForm reference, built-in validators,
 * CSS classes (ng-valid/ng-invalid/ng-touched), and form submission.
 */
@Component({
  selector: 'app-enrollment-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './enrollment-form.html',
  styleUrl: './enrollment-form.css'
})
export class EnrollmentFormComponent {
  submitted = false;
  submittedData: any = null;

  // Form model object (two-way bound via ngModel)
  formData = {
    studentName: '',
    studentEmail: '',
    courseId: '',
    preferredSemester: '',
    agreeToTerms: false
  };

  semesters = ['Odd', 'Even'];

  /** HO4 Task1 – onSubmit receives the NgForm instance from the template reference #enrollForm */
  onSubmit(form: NgForm): void {
    console.log('form.value:', form.value);
    console.log('form.valid:', form.valid);

    if (form.valid) {
      this.submitted = true;
      this.submittedData = { ...form.value };
    }
  }

  onReset(form: NgForm): void {
    form.resetForm();
    this.submitted = false;
    this.submittedData = null;
  }
}
