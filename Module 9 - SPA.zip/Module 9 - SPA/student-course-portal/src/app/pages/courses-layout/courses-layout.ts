import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/**
 * HO7 Task1 – Layout wrapper for nested /courses routes.
 * Contains a <router-outlet> for CourseListComponent and CourseDetailComponent.
 */
@Component({
  selector: 'app-courses-layout',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <div class="courses-layout">
      <router-outlet />
    </div>
  `,
  styles: ['.courses-layout { padding: 8px 0; }']
})
export class CoursesLayoutComponent {}
