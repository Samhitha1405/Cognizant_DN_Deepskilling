import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, FormArray, Validators, AbstractControl, ValidationErrors, FormControl } from '@angular/forms';


/**
 * HO5 – Reactive Enrollment Form
 * Demonstrates: FormBuilder, FormGroup, FormArray, custom sync/async validators,
 * dynamic controls, and typed getters.
 */

// HO5 Task2 – Custom synchronous validator (Step 53)
function noCourseCode(control: AbstractControl): ValidationErrors | null {
  const val = (control.value ?? '').toString().toUpperCase();
  return val.startsWith('XX') ? { noCourseCode: true } : null;
}

// HO5 Task2 – Custom async validator (Step 55)
// Returns a Promise; resolves after 800ms to simulate an email-uniqueness API call.
// Angular only runs async validators AFTER all sync validators pass (avoids unnecessary API calls).
function simulateEmailCheck(control: AbstractControl): Promise<ValidationErrors | null> {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(control.value?.includes('test@') ? { emailTaken: true } : null);
    }, 800);
  });
}

@Component({
  selector: 'app-reactive-enrollment-form',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './reactive-enrollment-form.html',
  styleUrl: './reactive-enrollment-form.css'
})
export class ReactiveEnrollmentFormComponent implements OnInit {
  enrollForm!: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // HO5 Task1 – Build form with FormBuilder (Step 49)
    this.enrollForm = this.fb.group({
      studentName:       ['', [Validators.required, Validators.minLength(3)]],
      // Third argument = array of async validators (Step 55)
      studentEmail:      ['', [Validators.required, Validators.email], [simulateEmailCheck]],
      courseId:          ['', [Validators.required, noCourseCode]],  // custom sync validator (Step 53)
      preferredSemester: ['Odd', Validators.required],
      agreeToTerms:      [false, Validators.requiredTrue],
      // FormArray for dynamic controls (Step 56)
      additionalCourses: this.fb.array([])
    });
  }

  /**
   * HO5 Task2 – Typed getter for FormArray (Step 57).
   * A getter is better than casting in the template because:
   * 1. The cast is written once in TypeScript, not repeated across the template.
   * 2. TypeScript checks the type at compile time.
   * 3. The template stays clean — no 'as FormArray' casts scattered in HTML.
   */
  get additionalCourses(): FormArray {
    return this.enrollForm.get('additionalCourses') as FormArray;
  }

  addCourse(): void {
    this.additionalCourses.push(this.fb.control('', Validators.required));
  }

  removeCourse(index: number): void {
    this.additionalCourses.removeAt(index);
  }

  onSubmit(): void {
    console.log('enrollForm.value:', this.enrollForm.value);
    // getRawValue() includes disabled controls; .value excludes them (HO5 Task1 Step 52)
    console.log('enrollForm.getRawValue():', this.enrollForm.getRawValue());
    if (this.enrollForm.valid) this.submitted = true;
  }
}
