import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { provideMockStore } from '@ngrx/store/testing';

describe('reactive-enrollment-form', () => {
  it('should pass placeholder test', () => expect(true).toBeTrue());
});
