import { Routes } from '@angular/router';
import { HomeComponent }           from './pages/home/home';
import { CoursesLayoutComponent }  from './pages/courses-layout/courses-layout';
import { CourseListComponent }     from './pages/course-list/course-list';
import { CourseDetailComponent }   from './pages/course-detail/course-detail';
import { StudentProfileComponent } from './pages/student-profile/student-profile';
import { EnrollmentFormComponent } from './pages/enrollment-form/enrollment-form';
import { ReactiveEnrollmentFormComponent } from './pages/reactive-enrollment-form/reactive-enrollment-form';
import { NotFoundComponent }       from './pages/not-found/not-found';
import { authGuard }               from './guards/auth-guard';
import { unsavedChangesGuard }     from './guards/unsaved-changes-guard';

export const routes: Routes = [
  { path: '', component: HomeComponent },

  // Nested routes under /courses (HO7 Task1)
  {
    path: 'courses',
    component: CoursesLayoutComponent,
    children: [
      { path: '',    component: CourseListComponent },
      { path: ':id', component: CourseDetailComponent }
    ]
  },

  // Protected routes (HO7 Task2 – authGuard)
  { path: 'profile', component: StudentProfileComponent, canActivate: [authGuard] },

  // Template-driven enrollment form (HO4)
  { path: 'enroll',  component: EnrollmentFormComponent, canActivate: [authGuard] },

  // Reactive enrollment form with unsaved-changes guard (HO5 + HO7)
  {
    path: 'enroll-reactive',
    component: ReactiveEnrollmentFormComponent,
    canActivate: [authGuard],
    canDeactivate: [unsavedChangesGuard]
  },

  // Wildcard — must be last (HO7 Task1)
  { path: '**', component: NotFoundComponent }
];
