import { courseReducer, initialCourseState } from './course.reducer';
import { loadCourses, loadCoursesSuccess, loadCoursesFailure } from './course.actions';
import { Course } from '../../models/course.model';

describe('CourseReducer', () => {
  const mockCourses: Course[] = [
    { id: 1, name: 'Data Structures', code: 'CS101', credits: 4, gradeStatus: 'passed' }
  ];

  it('should return the initial state', () => {
    const state = courseReducer(undefined, { type: '@@INIT' } as any);
    expect(state).toEqual(initialCourseState);
  });

  it('should set loading=true on loadCourses', () => {
    const state = courseReducer(initialCourseState, loadCourses());
    expect(state.loading).toBeTrue();
    expect(state.error).toBeNull();
  });

  it('should populate courses on loadCoursesSuccess', () => {
    const state = courseReducer(initialCourseState, loadCoursesSuccess({ courses: mockCourses }));
    expect(state.courses.length).toBe(1);
    expect(state.loading).toBeFalse();
  });

  it('should set error on loadCoursesFailure', () => {
    const state = courseReducer(initialCourseState, loadCoursesFailure({ error: 'Network error' }));
    expect(state.error).toBe('Network error');
    expect(state.loading).toBeFalse();
  });
});
