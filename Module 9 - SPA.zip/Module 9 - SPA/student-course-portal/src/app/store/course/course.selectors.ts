import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CourseState } from './course.reducer';

// HO9 Task1 – Selectors
// Selectors are memoised — they only recompute when their input selectors' values change.
// This is NgRx's key performance optimisation over plain service subscriptions.

export const selectCourseState = createFeatureSelector<CourseState>('course');

export const selectAllCourses    = createSelector(selectCourseState, s => s.courses);
export const selectCoursesLoading = createSelector(selectCourseState, s => s.loading);
export const selectCoursesError   = createSelector(selectCourseState, s => s.error);
