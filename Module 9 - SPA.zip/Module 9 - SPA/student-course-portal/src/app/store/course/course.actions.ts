import { createAction, props } from '@ngrx/store';
import { Course } from '../../models/course.model';

// HO9 Task1 – Course Actions
// The [Course] prefix groups related actions in Redux DevTools for easy filtering.

export const loadCourses = createAction('[Course] Load Courses');

export const loadCoursesSuccess = createAction(
  '[Course] Load Courses Success',
  props<{ courses: Course[] }>()
);

export const loadCoursesFailure = createAction(
  '[Course] Load Courses Failure',
  props<{ error: string }>()
);
