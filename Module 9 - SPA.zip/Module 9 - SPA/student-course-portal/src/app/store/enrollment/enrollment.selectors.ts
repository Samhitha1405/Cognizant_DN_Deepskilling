import { createFeatureSelector, createSelector } from '@ngrx/store';
import { EnrollmentState } from './enrollment.reducer';
import { selectAllCourses } from '../course/course.selectors';

export const selectEnrollmentState = createFeatureSelector<EnrollmentState>('enrollment');
export const selectEnrolledIds     = createSelector(selectEnrollmentState, s => s.enrolledCourseIds);

// Cross-slice selector (HO9 Task2) — combines course and enrollment state slices.
// This is a powerful NgRx pattern: derive joined data without duplicating state in the store.
export const selectEnrolledCourses = createSelector(
  selectAllCourses,
  selectEnrolledIds,
  (courses, ids) => courses.filter(c => ids.includes(c.id))
);
