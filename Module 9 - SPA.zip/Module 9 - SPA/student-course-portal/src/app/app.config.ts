import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter }      from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideStore }       from '@ngrx/store';
import { provideEffects }     from '@ngrx/effects';
import { provideState }       from '@ngrx/store';
import { provideStoreDevtools } from '@ngrx/store-devtools';

import { routes }               from './app.routes';
import { authInterceptor }      from './interceptors/auth-interceptor';
import { errorHandlerInterceptor } from './interceptors/error-handler-interceptor';
import { loadingInterceptor }   from './interceptors/loading-interceptor';
import { courseReducer }        from './store/course/course.reducer';
import { enrollmentReducer }    from './store/enrollment/enrollment.reducer';
import { CourseEffects }        from './store/course/course.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(
      withInterceptors([authInterceptor, errorHandlerInterceptor, loadingInterceptor])
    ),
    provideStore(),
    provideState('course',     courseReducer),
    provideState('enrollment', enrollmentReducer),
    provideEffects([CourseEffects]),
    provideStoreDevtools({ maxAge: 25, logOnly: false })
  ]
};