import { Pipe, PipeTransform } from '@angular/core';

/**
 * HO3 Task3 – Custom Pipe
 * Transforms a numeric credits value into a human-readable label.
 * Usage in template: {{ course.credits | creditLabel }}
 * Pure pipe (default) — only re-runs when the input reference changes.
 */
@Pipe({
  name: 'creditLabel',
  standalone: true,
  pure: true   // pure: false would re-run on every change detection cycle — avoid unless necessary
})
export class CreditLabelPipe implements PipeTransform {
  transform(credits: number | null | undefined): string {
    if (credits === null || credits === undefined || credits === 0) return 'No Credits';
    return credits === 1 ? '1 Credit' : `${credits} Credits`;
  }
}
