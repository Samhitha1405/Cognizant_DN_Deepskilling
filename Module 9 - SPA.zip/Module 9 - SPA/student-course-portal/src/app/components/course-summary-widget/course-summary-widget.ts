import { Component, OnInit } from '@angular/core';
import { CourseService } from '../../services/course';

/**
 * HO6 Task1 – Second component using the same singleton CourseService.
 * Adding a course in CourseListComponent updates the count here — proving singleton DI.
 */
@Component({
  selector: 'app-course-summary-widget',
  standalone: true,
  imports: [],
  template: `
    <div class="widget">
      <h4>📊 Portal Summary <small>(via singleton CourseService)</small></h4>
      <p>Total courses in service: <strong>{{ total }}</strong></p>
    </div>
  `,
  styles: ['.widget { background:#f5f3ff; border:1px solid #c4b5fd; border-radius:10px; padding:14px 18px; margin-top:24px; } h4{margin:0 0 6px;color:#4f46e5;font-size:0.95rem;} small{color:#7c3aed;font-size:0.75rem;}']
})
export class CourseSummaryWidgetComponent implements OnInit {
  total = 0;
  constructor(private courseService: CourseService) {}
  ngOnInit(): void { this.total = this.courseService.getCoursesSync().length; }
}
