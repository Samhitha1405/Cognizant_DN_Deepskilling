import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth';

/**
 * HO1 Task2 – Header component with nav links
 * HO7 – Integrated login/logout toggle for auth guard demo
 */
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './header.html',
  styleUrl: './header.css'
})
export class HeaderComponent {
  constructor(public authService: AuthService) {}

  toggleLogin(): void {
    if (this.authService.isLoggedIn) {
      this.authService.logout();
    } else {
      this.authService.login();
    }
  }
}
