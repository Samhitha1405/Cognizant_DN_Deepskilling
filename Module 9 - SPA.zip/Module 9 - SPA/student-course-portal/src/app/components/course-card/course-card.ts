import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { NgClass, NgStyle, NgSwitch, NgSwitchCase, NgSwitchDefault } from '@angular/common';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AsyncPipe } from '@angular/common';
import { Course } from '../../models/course.model';
import { HighlightDirective } from '../../directives/highlight';
import { CreditLabelPipe } from '../../pipes/credit-label-pipe';
import { EnrollmentService } from '../../services/enrollment';
import { enrollInCourse, unenrollFromCourse } from '../../store/enrollment/enrollment.actions';
import { selectEnrolledIds } from '../../store/enrollment/enrollment.selectors';

/**
 * HO2 Task2 – ngOnChanges lifecycle hook
 * HO2 Task3 – @Input and @Output decorators
 * HO3 Task1 – *ngSwitch for grade status badge
 * HO3 Task2 – [ngClass] and [ngStyle] attribute directives
 * HO3 Task3 – appHighlight directive and creditLabel pipe applied here
 * HO6 Task2 – EnrollmentService injected for enroll/unenroll
 * HO9 Task2 – NgRx store for enrollment state
 */
@Component({
  selector: 'app-course-card',
  standalone: true,
  imports: [NgClass, NgStyle, NgSwitch, NgSwitchCase, NgSwitchDefault, AsyncPipe, HighlightDirective, CreditLabelPipe],
  templateUrl: './course-card.html',
  styleUrl: './course-card.css'
})
export class CourseCardComponent implements OnChanges {
  // HO2 Task3 – @Input: receives a Course object from parent (CourseListComponent)
  @Input() course!: Course;

  // HO2 Task3 – @Output: emits the course id when Enroll is clicked
  @Output() enrollRequested = new EventEmitter<number>();

  // Controls the expanded/collapsed state (HO3 Task2 Step 31)
  isExpanded = false;

  // NgRx enrolled IDs stream (HO9 Task2)
  enrolledIds$: Observable<number[]>;

  constructor(
    private enrollmentService: EnrollmentService,
    private store: Store
  ) {
    this.enrolledIds$ = this.store.select(selectEnrolledIds);
  }

  /**
   * HO2 Task2 – ngOnChanges fires whenever an @Input value changes.
   * Logs previous and current values for debugging — more useful than ngOnInit
   * for components that receive changing data from a parent.
   */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['course']) {
      const prev = changes['course'].previousValue;
      const curr = changes['course'].currentValue;
      console.log(`[CourseCard] ngOnChanges — course changed from`, prev?.name ?? 'undefined', '→', curr?.name);
    }
  }

  /**
   * HO3 Task2 – Getter for ngClass object binding.
   * Using a getter keeps the template clean — complex logic stays in the class.
   * [ngClass]="cardClasses" is cleaner than an inline object literal in the template.
   */
  get cardClasses(): Record<string, boolean> {
    return {
      'card--enrolled': this.enrollmentService.isEnrolled(this.course?.id),
      'card--full':     (this.course?.credits ?? 0) >= 4,
      'expanded':       this.isExpanded
    };
  }

  /** HO3 Task2 – Dynamic left border colour via [ngStyle] based on gradeStatus */
  get borderStyle(): Record<string, string> {
    const colours: Record<string, string> = { passed: '#10b981', failed: '#ef4444', pending: '#9ca3af' };
    return { 'border-left-color': colours[this.course?.gradeStatus] ?? '#9ca3af' };
  }

  toggleExpand(): void { this.isExpanded = !this.isExpanded; }

  /** HO6 Task2 + HO9 Task2 — dispatch NgRx action and also update service */
  onEnrollToggle(): void {
    if (this.enrollmentService.isEnrolled(this.course.id)) {
      this.store.dispatch(unenrollFromCourse({ courseId: this.course.id }));
      this.enrollmentService.unenroll(this.course.id);
    } else {
      this.store.dispatch(enrollInCourse({ courseId: this.course.id }));
      this.enrollmentService.enroll(this.course.id);
      this.enrollRequested.emit(this.course.id);  // HO2 Task3
    }
  }
}
