import { Component, OnInit } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { NotificationService } from '../../services/notification';

/**
 * HO6 Task2 – Component-level provider.
 * providers: [NotificationService] creates a NEW instance scoped to this component
 * and its children — separate from any root-level NotificationService instance.
 *
 * Why use component-level providers?
 * Useful when you need ISOLATED state per component instance, e.g.
 * a multi-step wizard where each step manages its own notification stack.
 */
@Component({
  selector: 'app-notification',
  standalone: true,
  imports: [AsyncPipe],
  providers: [NotificationService],  // ← scoped instance; NOT the root singleton
  template: `
    <div class="notification-panel">
      @for (msg of notifService.messages | async; track msg) {
        <div class="notif-item">{{ msg }}</div>
      }
      <button (click)="notifService.push('Test notification ' + (++count))">Add Notification</button>
      <button (click)="notifService.clear()">Clear</button>
    </div>
  `,
  styles: ['.notification-panel{padding:12px;border:1px dashed #a5b4fc;border-radius:8px;margin-top:12px}.notif-item{background:#ede9fe;padding:6px 12px;border-radius:6px;margin:4px 0;font-size:0.85rem}button{margin:4px;padding:6px 12px;border:1px solid #c4b5fd;background:#f5f3ff;border-radius:6px;cursor:pointer}']
})
export class NotificationComponent implements OnInit {
  count = 0;
  constructor(public notifService: NotificationService) {}
  ngOnInit(): void { this.notifService.push('Welcome to the portal!'); }
}
